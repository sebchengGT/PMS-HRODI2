import csv
import json
import base64
import html

def safe_get(row, key):
    # Strip whitespace AND remove Zero Width Space (U+200B)
    return row.get(key, '').replace('\u200b', '').strip()

def create_detail_html(title, data_dict):
    """
    Creates an HTML string for the modal content representing the details.
    data_dict: { 'Label': 'Value' }
    """
    rows_html = ""
    for label, value in data_dict.items():
        if value:
            rows_html += f"""
            <div class="border-b border-slate-100 last:border-0 py-3">
                <p class="text-xs font-bold text-slate-500 uppercase tracking-wide mb-1">{label}</p>
                <div class="text-slate-800 text-sm whitespace-pre-wrap">{html.escape(value)}</div>
            </div>
            """
    
    return f"""
    <div class="space-y-2">
        {rows_html}
    </div>
    """

def create_card_html(title, subtitle, type_color, type_label, detail_html_base64):
    """
    Creates the clickable card HTML.
    """
    # Truncate title if too long for the card preview
    display_title = (title[:75] + '...') if len(title) > 80 else title
    
    # Escape strictly for JS: replace newlines to avoid invalid string literals
    # Must escape backslashes first, then single quotes (for JS), then html escape (for attribute)
    safe_title = title.replace('\\', '\\\\').replace("'", "\\'").replace('\n', ' ').replace('\r', '')
    safe_title_js = html.escape(safe_title, quote=True)
    
    return f"""
    <div onclick="openModal('{safe_title_js}', '{detail_html_base64}')" 
         class="bg-white rounded-lg shadow-sm border border-slate-200 p-5 hover:shadow-md transition-all cursor-pointer group hover:border-blue-300 relative overflow-hidden flex flex-col h-full">
        
        <div class="absolute top-0 left-0 w-1 h-full bg-{type_color}-500"></div>
        
        <div class="mb-3">
            <span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-{type_color}-50 text-{type_color}-700">
                {type_label}
            </span>
        </div>
        
        <h4 class="text-md font-bold text-slate-800 mb-2 group-hover:text-blue-700 transition-colors line-clamp-3">
            {html.escape(display_title)}
        </h4>
        
        <p class="text-xs text-slate-500 mt-auto pt-4 border-t border-slate-100 flex items-center">
            <span class="bg-slate-100 rounded-full p-1 mr-2 group-hover:bg-blue-100 group-hover:text-blue-600 transition-colors">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
            </span>
            Click to view details
        </p>
    </div>
    """

def generate_basecamp_html():
    csv_file = 'HRODI Accomplishments.csv'
    
    # Mapping of CSV header names
    # Basecamp, Program
    
    # Buckets
    categories = {
        'Accomplishments': {
            'color': 'green',
            'fields': [
                ('Title', 'Accomplishment Title'),
                ('Description', 'Accomplishment Description'),
                ('Date', 'Accomplishment Date')
            ]
        },
        'Milestones': {
            'color': 'blue',
            'fields': [
                ('Title', 'Milestone Title'),
                ('Description', 'Milestone Description'),
                ('Physical Target', 'Milestone Physical Accomplishment'),
                ('Financial Target', 'Milestone Financial Accomplishment'),
                ('Date', 'Milestone Date')
            ]
        },
        'Bottlenecks': {
            'color': 'red',
            'fields': [
                ('Issue', 'Bottlenecks') # Assuming this is the title/description
            ]
        },
        'Spillovers': {
            'color': 'orange',
            'fields': [
                ('Title', 'Spillover Title'),
                ('Description', 'Spillover Description'),
                ('Initial Target', 'Spillover Initial Target'),
                ('New Target', 'Spillover New Target')
            ]
        },
        'Catch-up Plans': {
            'color': 'purple',
            'fields': [
                ('Title', 'Catch-up Activities Title'),
                ('Description', 'Catchup Activities Description'),
                ('Target Date', 'Catchup Activities Target Date') # Corrected from CSV 'Catchup' vs 'Catch-up' based on previous context, but will verify with get call if needed. 
                # User prompt said "Catchup Activities Title", "Catchup Activities Description". 
                # Checking exact CSV header line provided earlier: 
                # "Catch-up Activities Title,Catchup Activities Description,Catchup Activities Target Date"
            ]
        }
    }

    # Data Structure:
    # basecamp_data[basecamp_name][program_name][category_name] = [list of html cards]
    basecamp_data = {}

    # Map Basecamp Names to IDs
    basecamp_id_map = {
        'Career Progression for DepEd Personnel': 'base-careerprog',
        'Mental Health Professionals for Schools': 'base-mentalhealth',
        'Workforce Plan and Management': 'base-workforceplan',
        'HROD Process Excellence': 'base-hrodprocess',
        'Prioritization Index for Education Facilities Allocation': 'base-prioritization',
        'Career Opportunities in DepEd for SHS Graduates': 'base-careeropp',
        'Other PAPs': 'base-otherpaps'
    }

    seen_items = set()

    try:
        with open(csv_file, mode='r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            print(f"DEBUG: Headers found: {reader.fieldnames}")
            
            for row in reader:
                basecamp = safe_get(row, 'Basecamp')
                program = safe_get(row, 'Program')
                
                # print(f"DEBUG: Row Basecamp: '{basecamp}'") 
                
                if not basecamp or not program:
                    continue
                    
                if basecamp not in basecamp_data:
                    basecamp_data[basecamp] = {}
                
                if program not in basecamp_data[basecamp]:
                    basecamp_data[basecamp][program] = {cat: [] for cat in categories}
                
                # Check each category for data in this row
                for cat_name, cat_config in categories.items():
                    # We consider a category "present" if the FIRST field has data (Title/Issue)
                    first_field_csv_name = cat_config['fields'][0][1]
                    title_value = safe_get(row, first_field_csv_name)
                    
                    # Filter N/A or empty
                    if not title_value or title_value.lower() in ['n/a', 'na', 'none', '-']:
                        continue
                        
                    # Collect all details
                    detail_data = {}
                    has_na_content = False
                    for label, csv_col in cat_config['fields']:
                        val = safe_get(row, csv_col)
                        if val.lower() == 'n/a':
                            val = "" # Clear N/A values in details, or skip entire item? User said "cards with N/A". 
                            # Safe assumption: If the MAIN title is N/A, skip. If desc is N/A, maybe just hide desc.
                            # But request said "cards with duplicate title and description as well as cards with N/A".
                            # Let's interpret strictly: if Title OR Description is "N/A", skip.
                        detail_data[label] = val
                    
                    # Stricter N/A check
                    description_field = cat_config['fields'][1][1] if len(cat_config['fields']) > 1 else None
                    desc_value = safe_get(row, description_field) if description_field else ""
                    
                    if desc_value.lower() in ['n/a', 'na']:
                        continue

                    # Generate Card HTML
                    subtitle = desc_value
                    if len(subtitle) > 100: subtitle = subtitle[:100] + "..."
                    
                    # Deduplication Key: (Program, Category, Title, Subtitle)
                    # We need to track this globally or per program.
                    # Let's use a composite key for the `seen_items` set.
                    # We need to initialize seen_items outside.
                    
                    unique_key = (program, cat_name, title_value, desc_value)
                    if unique_key in seen_items:
                        continue
                    seen_items.add(unique_key)

                    # Generate Detail HTML
                    detail_html = create_detail_html(title_value, detail_data)
                    detail_base64 = base64.b64encode(detail_html.encode('utf-8')).decode('utf-8')
                    
                    card_html = create_card_html(title_value, subtitle, cat_config['color'], cat_name, detail_base64)
                    
                    basecamp_data[basecamp][program][cat_name].append(card_html)

        # Generate Final HTML for each Basecamp ID
        output_json = {}
        
        for basecamp, programs in basecamp_data.items():
            base_id = basecamp_id_map.get(basecamp)
            if not base_id:
                print(f"Warning: No ID found for Basecamp '{basecamp}'")
                continue
                
            # Build the inner HTML for this panel
            panel_html = f"""
            <div>
                <h2 class="text-3xl font-bold text-slate-800 mb-6">{basecamp}</h2>
            </div>
            <div class="space-y-12">
            """
            
            for program, cats in programs.items():
                # Check if program has ANY data
                has_data = any(len(cards) > 0 for cards in cats.values())
                if not has_data:
                    continue
                    
                panel_html += f"""
                <div class="bg-slate-50 rounded-xl p-6 border border-slate-200">
                    <h3 class="text-xl font-bold text-slate-800 mb-6 flex items-center border-b border-slate-200 pb-2">
                        <i data-lucide="folder-open" class="w-5 h-5 mr-3 text-blue-600"></i>
                        {program}
                    </h3>
                    <div class="space-y-8">
                """
                
                for cat_name, cards in cats.items():
                    if not cards:
                        continue
                        
                    config = categories[cat_name]
                    color = config['color']
                    
                    panel_html += f"""
                        <div>
                            <h4 class="text-sm font-bold text-{color}-700 uppercase tracking-wider mb-3 flex items-center">
                                <span class="w-2 h-2 rounded-full bg-{color}-500 mr-2"></span>
                                {cat_name}
                            </h4>
                            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {''.join(cards)}
                            </div>
                        </div>
                    """
                
                panel_html += """
                    </div>
                </div>
                """
            
            panel_html += "</div>"
            output_json[base_id] = panel_html

        # Save to JSON
        with open('generated_content.json', 'w', encoding='utf-8') as f:
            json.dump(output_json, f, indent=4)
            
        print(f"Successfully generated HTML for ids: {list(output_json.keys())}")

    except Exception as e:
        print(f"Error generation failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    generate_basecamp_html()
